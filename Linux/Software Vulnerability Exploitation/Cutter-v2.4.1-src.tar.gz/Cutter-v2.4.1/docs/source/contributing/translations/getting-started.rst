Translate Cutter
==================

Help Cutter by adding translations to the project!

Cutter is a global project with users from all around the world. We believe that Cutter should be as accessible as possible, and want our users to feel comfortable while using its interface. Providing our community an interface with their own language makes the experience of using Cutter better. Thus, Cutter supports a translation and localization mechanism powered by the `Crowdin <https://crowdin.com/project/cutter>`_ platform. We invite you to contribute and add translations to the project.


.. important::
  We currently support more than 15 languages. If you need to add a language that isn't available yet, ask any developer from the team and they will happily assist you.
