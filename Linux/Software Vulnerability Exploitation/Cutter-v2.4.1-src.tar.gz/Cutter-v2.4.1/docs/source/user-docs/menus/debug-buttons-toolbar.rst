Debug Buttons Toolbar
==============================

Continue until Main 
----------------------------------------
**Description:** Continue the execution of the program until the Main function is reached.  

**Steps:**  Continue until main  

Continue until Call
----------------------------------------
**Description:** Continue the execution of the program until a function call is reached.  

**Steps:**  Continue until call  

Continue until Syscall
----------------------------------------
**Description:** Continue the execution of the program until a Syscall is reached.  

**Steps:**  Continue until syscall