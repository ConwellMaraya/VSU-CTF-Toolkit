Menus
======

This part of the user documentation will provide the reader with information about the different menus and context menu items they can find on Cutter. Each item has a description that explains about its actions, as well as how to reach this feature from the UI and a keyboard shortcut if one assigned to the feature.


.. toctree::
   :maxdepth: 3
   :glob:

   menus/*

 
